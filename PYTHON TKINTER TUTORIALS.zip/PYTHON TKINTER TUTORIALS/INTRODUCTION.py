from tkinter import *
root = Tk()
root.geometry('1000x400')
l1 = Label(root, text="JAGADEESWARAN",font=("sanserif",50),bg="green",fg="blue",width="20")
l1.pack()
root.mainloop()