
# Tic Tac Toe 
<p align="center">

## Description

A Tic Tac Toe game built in Python.

## Library Used
`import tkinter`

## How to run
Running the script is really simple! Just open a terminal in the folder where your script is located and run the following command:

```sh
python tic_tac_toe.py
```

## Author
[Anokh1](https://github.com/Anokh1)

